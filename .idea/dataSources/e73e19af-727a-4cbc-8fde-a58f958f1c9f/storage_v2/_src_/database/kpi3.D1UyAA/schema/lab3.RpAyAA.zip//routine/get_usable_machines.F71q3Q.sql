create function get_usable_machines(balancer integer) returns SETOF integer
    language sql
as
$$
select id from machines
    where balancer_id = balancer and usable = true
$$;

alter function get_usable_machines(integer) owner to postgres;

