create function get_machines_quantity(balancer integer) returns bigint
    language sql
as
$$
select count(*) from machines
    where balancer_id = balancer;
$$;

alter function get_machines_quantity(integer) owner to postgres;

